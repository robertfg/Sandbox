package eye;

public interface OffHeapInt {
   
   public void setIndex(int index);
   public void setKey(int key);
   public void setValue(int value);
   
   public int getIndex();
   public int getIndex(int  value); //get object index using value
   
   public int getKey();
   public int getKey(int index);   //get value using index
   
   
   public int getValue();
   public int getValue(int index); //get value using index
   
   public void jump(int index);
   
   public boolean exist(int value);
   
   public int create(int key, int value);
  
   
   public int[] getKV(int index);
   
   public int getV(int K);
   public int[] getVs(int K);
   
   public int getK(int V);
   public int[] getKs(int V);
   
   public boolean containsKey(int key);
   public boolean containsValue(int value);
    
   
}
