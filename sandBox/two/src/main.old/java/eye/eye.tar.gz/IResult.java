package eye;

public interface IResult {
	
	//public int[] results;
	public IResult search();
	
		
}
